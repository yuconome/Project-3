Width = 1920
Height = 1080
Resolution = (Width, Height)
BackgroundColor = (10, 10,10)
sens= 200 #mouse sensitivity
