class Object:
    def __init__(self, position):
        self.position = position
        self.transform = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
